#!/bin/bash          
lessc teibp.less > teibp.css
lessc sleepy.less > sleepy.css
lessc terminal.less > terminal.css
